'use strict';

const Homey = require('homey');
const fetch = require('node-fetch');

class MyDriver extends Homey.Driver {

}

module.exports = MyDriver;