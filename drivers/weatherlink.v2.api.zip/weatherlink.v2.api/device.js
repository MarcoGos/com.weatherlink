'use strict';

const Homey = require('homey');
const fetch = require('node-fetch');

class MyDevice extends Homey.Device {

    timerElapsed(device) {
		setTimeout(function () { device.timerElapsed(device); }, device.getSetting('interval') * 1000);

        let measurements =
			[
				{ "capability": "measure_temperature", "factor": 1, "field": "temp_c" },
                { "capability": "measure_pressure", "factor": 1, "field": "pressure_mb" },
                { "capability": "measure_humidity", "factor": 1, "field": "relative_humidity" },
	            { "capability": "measure_rain", "factor": 1, "field": "rain_day_in" },
                { "capability": "measure_wind_angle", "factor": 1, "field": "wind_degrees" },
                { "capability": "measure_wind_strength", "factor": 1.61, "field": "wind_mph" }
    		]

        let url = device._getUrl(device);
        console.log(url)
        fetch(url).then(function (response) {
            response.json().then(function (json) {
                console.log(json)
                measurements.forEach(measurement => {
                    device._updateProperty(measurement.capability, json[measurement.field] * measurement.factor);
                });
            });
        }).catch(function (err) {
            console.log(err)
        });
    }

    _getUrl(device) {
        var crypto = require("crypto");

        let apiSecret = device.getSetting('apisecret');
        let parameters = {
            "api-key": device.getSetting('apikey'),
            "station-id": device.getSetting('stationid'),
            "t": Math.floor(Date.now() / 1000)
        }

        var data = "";
        for (var parameter in parameters) {
            data += parameter + parameters[parameter]
        }

        var hmac = crypto.createHmac("sha256", apiSecret);
        hmac.update(data);
        var apiSignature = hmac.digest("hex");

        return `https://api.weatherlink.com/v2/current/${parameters["station-id"]}?api-key=${parameters["api-key"]}&api-signature=${apiSignature}&t=${parameters["t"]}`
    }

    _updateProperty(key, value) {
		if (this.hasCapability(key)) {
			let oldValue = this.getCapabilityValue(key);
			if (oldValue !== null && oldValue != value) {
				this.setCapabilityValue(key, value);
            } else {
                this.setCapabilityValue(key, value);
            }
        }
    }
    
	onInit() {
		this.log('WeatherLink v2 API init');
		this.log('Name:', this.getName());
		this.log('Class:', this.getClass());
		this.log('Interval:', this.getSetting('interval'));

		var device = this;
		setTimeout(function () { device.timerElapsed(device); }, 1000);
	}
}

module.exports = MyDevice;